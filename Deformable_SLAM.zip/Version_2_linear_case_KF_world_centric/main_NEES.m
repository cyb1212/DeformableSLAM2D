%This code is used to present an linear deformable SLAM framework with
%several poses and 3 deforming features using the traditional measurement,
%struction constaint, and smooth constraint based on the Kalman Filter

% Copyright (C) 2020 by Yongbo Chen, Shoudong Huang, Liang Zhao, and Yanhao
% Zhang

%% Clear environment
clc
clear
% close all
warning off
addpath('./Math/');%All mathmatical part espically Lie group
load noise_data_100steps.mat;

%% Initialization
Num_pose=100;%Total number of the poses
Num_feature=3;%Total number of the features
feature=[0.5,0.5;0.9,0.8;0.3,0.4]';%Generate fixed feature in initial frame
Pose=[0;0];%Coordinate of the first pose
V_angle=0;%Direction of the first pose
rotation_t=eye(2);%No rotation for global translation
rotation_d=eye(2);%No rotation for local deformation
translation=repmat([1;0],[1,Num_pose]);%random Features global motion
v=[0;ones(Num_pose-1,1)];%The constant translation in every iteration (velocity)
sigma_smoo=0.03;
sigma_cons=0.02;
sigma_odem=0.002;
sigma_feat=0.005;
noise_odem1=[[0;0],noise_odem1];
%% KF based deformable SLAM
visble(:,1)=[1,1,1];
for i=1:1:Num_feature
    for j=2:1:Num_pose
        if rand(1,1)>0.8
            visble(i,j)=1;
        else
            visble(i,j)=1;
        end
    end
end
constraint_edge=[];
for i=1:1:Num_feature
    for j=i+1:1:Num_feature
        constraint_edge=[constraint_edge;i,j];%The realtive edge in the construction
    end
end
% figure,
for i=1:1:Num_pose
%     subplot(1,Num_pose,i);
%     axis equal;
    %% Ground truth of the poses
    Pose(1,i)=sum(v(1:i));
    Pose(2,i)=0;
    V_angle(i)=0;
    local_cordinate_feature{1}(1:2,i)=[0;0];%Local coordinate of the first feature at the first frame
    d_local_feature{1}(1:2,i)=zeros(2,1);%Local deformation of the first feature at the first frame
%     make_plane(Pose(1:2,i), V_angle(i), 0.05, [0,1,1]);%Plot a vehicle to represent a pose
    %% Ground truth of the features
    for j=1:1:Num_feature
        feature_frame{j}(1:2,i)=feature(1:2,j);%Dynamic only features
        feature(1:2,j)=feature(1:2,j)+rotation_t*translation(1:2,i)+noise_smoo1{j}(:,i);%;
        local_cordinate_feature{j}(1:2,i)=feature_frame{j}(1:2,i)-feature_frame{1}(1:2,i);%Local coordinate of the features
        d_local_feature{j}(1:2,i)=zeros(2,1);%Local deformation of the features
        feature_frame{j}(1:2,i)=feature_frame{j}(1:2,i)+rotation_d*d_local_feature{j}(1:2,i)+noise_cons1{j}(:,i);
%         plot(feature_frame{j}(1,i),feature_frame{j}(2,i),'g*');%Features in different frame
%         if i==Num_pose
%             plot(feature_frame{j}(1,:),feature_frame{j}(2,:),'-r');%Track feature
%         end
    end
    %% KF
    if i==1
        X_update=zeros(1*2,1);
        for j=1:1:Num_feature
            X_update=[X_update;feature_frame{j}(1:2,1)+normrnd(0,sigma_feat,2,1)];
        end
        PX=zeros(2*(Num_feature+1),2*(Num_feature+1));
        PX(3:end,3:end)=sigma_feat^2*eye(2*Num_feature);
    else
        %% Smooth measurement
        for j=1:1:Num_feature
            measurement_smooth{j,i}=rotation_t*translation(1:2,i)+d_local_feature{j}(1:2,i);
        end
        %% Prediction
        Q=blkdiag(sigma_odem^2*eye(2),(sigma_smoo^2+sigma_cons^2)*eye(2),...
          (sigma_smoo^2+sigma_cons^2)*eye(2),(sigma_smoo^2+sigma_cons^2)*eye(2));
        [PX_predict,X_update_predict]=predict_noise(v(i),V_angle(i),Q,PX,sigma_odem,X_update,measurement_smooth,i,noise_odem1);
        %% KF Gain
        N=[];
        for j=1:1:Num_feature
            if visble(j,i)==1
                N=blkdiag(N,sigma_feat^2*eye(2));
            end
        end
        for j=1:1:size(constraint_edge,1)
            N=blkdiag(N,sigma_cons^2*eye(2));
        end
        [K,H]=KF_gain(PX_predict,V_angle(i),N,visble(:,i),constraint_edge,Num_feature);
        %% Construction measurement
        for j=1:1:size(constraint_edge,1)
            measurement_construction{i,j}=local_cordinate_feature{constraint_edge(j,2)}(1:2,i)+...        
            rotation_d*d_local_feature{constraint_edge(j,2)}(1:2,i)-...
            local_cordinate_feature{constraint_edge(j,1)}(1:2,i)-... 
            rotation_d*d_local_feature{constraint_edge(j,1)}(1:2,i);
        end
        %% Feature measurement
        for j=1:1:Num_feature
            if visble(j,i)==1
                measurement_feature{i,j}=so2_exp(V_angle(i))'*(feature_frame{j}(1:2,i)-Pose(1:2,i))+noise_feat1{j}(:,i);
            else
                measurement_feature{i,j}=[];
            end
        end
        %% Update
        [X_update,PX]=KF_update(X_update_predict,K,measurement_construction,measurement_feature,H,PX_predict,i,constraint_edge);
    end
    dx(i)=X_update(1)-Pose(1,i);
    dy(i)=X_update(2)-Pose(2,i);
    Cov_x(i)=2*sqrt(PX(1,1));
    Cov_x_negative(i)=-2*sqrt(PX(1,1));
    Cov_y(i)=2*sqrt(PX(2,2));
    Cov_y_negative(i)=-2*sqrt(PX(2,2));
    for j=1:1:Num_feature%Features in different frames
        df_x{j}(i)=X_update(2+j*2-1)-feature_frame{j}(1,i);
        df_y{j}(i)=X_update(2+j*2)-feature_frame{j}(2,i);
        dfCov_x{j}(i)=2*sqrt(PX(2+j*2-1,2+j*2-1));
        dfCov_y{j}(i)=2*sqrt(PX(2+j*2,2+j*2));
        dfCov_x_negative{j}(i)=-2*sqrt(PX(2+j*2-1,2+j*2-1));
        dfCov_y_negative{j}(i)=-2*sqrt(PX(2+j*2,2+j*2));
    end
    %% Draw
%     plot(X_update(1),X_update(2),'*b');%Track feature
%     plot_elipse(X_update(1:2),PX(1:2,1:2)); %Covariance elipse
%     for j=1:1:Num_feature
%         if visble(j,i)==1
%             plot([feature_frame{j}(1,i),Pose(1,i)],[feature_frame{j}(2,i),Pose(2,i)],'--b');%Features measurement
%         else
%             plot([feature_frame{j}(1,i),Pose(1,i)],[feature_frame{j}(2,i),Pose(2,i)],'--y');%Features measurement
%         end
%         plot(X_update(2+2*j-1),X_update(2+2*j),'*k');%Track feature
%         plot_elipse(feature_frame{j}(1:2,i),PX(2+j*2-1:2+j*2,2+j*2-1:2+j*2)); %Covariance elipse
%     end
%     for j=1:1:Num_feature-1
%         plot([feature_frame{j}(1,i),feature_frame{j+1}(1,i)],[feature_frame{j}(2,i),feature_frame{j+1}(2,i)],'--b');%Features measurement
%     end
%     j=Num_feature;
%     plot([feature_frame{j}(1,i),feature_frame{1}(1,i)],[feature_frame{j}(2,i),feature_frame{1}(2,i)],'--b');%Features measurement
end
%% Plot estimation result
subplot(8,2,2);
hold on;
title('Estimation error: KF');
plot(dx,'r','linewidth',2);
plot(Cov_x,'--k','linewidth',1);
plot(Cov_x_negative,'--k','linewidth',1);
subplot(8,2,4);
hold on;
plot(dy,'r','linewidth',2);
plot(Cov_y,'--k','linewidth',1);
plot(Cov_y_negative,'--k','linewidth',1);
subplot(8,2,6);
hold on;
plot(df_x{1},'r','linewidth',2);
plot(dfCov_x{1},'--k','linewidth',1);
plot(dfCov_x_negative{1},'--k','linewidth',1);
subplot(8,2,8);
hold on;
plot(df_y{1},'r','linewidth',2);
plot(dfCov_y{1},'--k','linewidth',1);
plot(dfCov_y_negative{1},'--k','linewidth',1);
subplot(8,2,10);
hold on;
plot(df_x{2},'r','linewidth',2);
plot(dfCov_x{2},'--k','linewidth',1);
plot(dfCov_x_negative{2},'--k','linewidth',1);
subplot(8,2,12);
hold on;
plot(df_y{2},'r','linewidth',2);
plot(dfCov_y{2},'--k','linewidth',1);
plot(dfCov_y_negative{2},'--k','linewidth',1);
subplot(8,2,14);
hold on;
plot(df_x{3},'r','linewidth',2);
plot(dfCov_x{3},'--k','linewidth',1);
plot(dfCov_x_negative{3},'--k','linewidth',1);
subplot(8,2,16);
hold on;
plot(df_y{3},'r','linewidth',2);
plot(dfCov_y{3},'--k','linewidth',1);
plot(dfCov_y_negative{3},'--k','linewidth',1);
xlabel('time step');