%This code is used to present an linear deformable SLAM framework with
%several poses and 3 deforming features using the traditional measurement,
%struction constaint, and smooth constraint based on the Kalman Filter

% Copyright (C) 2020 by Yongbo Chen, Shoudong Huang, Liang Zhao, and Yanhao
% Zhang

%% Clear environment
clc
clear
close all
warning off
addpath('./Math/');%All mathmatical part espically Lie group

%% Initialization
Num_pose=10;%Total number of the poses
Num_feature=3;%Total number of the features
feature=[0.5,0.5;0.9,0.8;0.3,0.4]';%Generate fixed feature in initial frame
Pose=[0;0];%Coordinate of the first pose
V_angle=0;%Direction of the first pose
rotation_t=eye(2);%No rotation for global translation
rotation_d=eye(2);%No rotation for local deformation
translation=repmat([1;0],[1,Num_pose]);%random Features global motion
v=[0;ones(Num_pose-1,1)];%The constant translation in every iteration (velocity)
sigma_odem=0.02;%Odometry noise
sigma_smoo=0.03;%smooth noise for the dynamic translation only
sigma_cons=0.03;%construsture noise for the local deformation only
sigma_feat=0.01;%feature measurement noise
%% KF based deformable SLAM
visble(:,1)=[1,1,1];
for i=1:1:Num_feature
    for j=2:1:Num_pose
        if rand(1,1)>0.8
            visble(i,j)=0;
        else
            visble(i,j)=1;
        end
    end
end
constraint_edge=[];
for i=1:1:Num_feature
    for j=i+1:1:Num_feature
        constraint_edge=[constraint_edge;i,j];%The realtive edge in the construction
    end
end
i=1;
for j=1:1:Num_feature
    feature_frame{j}(1:2,i)=feature(1:2,j);%Dynamic only features
%     feature(1:2,j)=feature(1:2,j)+rotation_t*translation(1:2,i)+normrnd(0,sigma_smoo,2,1);%;
%     local_cordinate_feature{j}(1:2,i)=feature_frame{j}(1:2,i)-feature_frame{1}(1:2,i);%Local coordinate of the features
    d_local_feature{j}(1:2,i)=zeros(2,1);%Local deformation of the features
    noise_record{j}=normrnd(0,sigma_cons,2,1);
    feature_frame{j}(1:2,i)=feature_frame{j}(1:2,i)+rotation_d*d_local_feature{j}(1:2,i)+noise_record{j};
end
point1=feature_frame{1}(1:2,1);
point2=feature_frame{2}(1:2,1);
theta=atan((point2(2)-point1(2))/(point2(1)-point1(1)));
R_ground=[cos(theta),-sin(theta);sin(theta),cos(theta)];
for i=1:1:Num_pose
    %% Ground truth of the poses
    Pose(1,i)=sum(v(1:i));
    Pose(2,i)=0;
    V_angle(i)=0;
    local_cordinate_feature{1}(1:2,i)=[0;0];%Local coordinate of the first feature at the first frame
    d_local_feature{1}(1:2,i)=zeros(2,1);%Local deformation of the first feature at the first frame
    make_plane(R_ground'*(Pose(1:2,i)-point1), V_angle(i), 0.05, [0,1,1]);%Plot a vehicle to represent a pose
    %% Ground truth of the features
    for j=1:1:Num_feature
        feature_frame{j}(1:2,i)=feature(1:2,j);%Dynamic only features
        feature(1:2,j)=feature(1:2,j)+rotation_t*translation(1:2,i)+normrnd(0,sigma_smoo,2,1);%;
        local_cordinate_feature{j}(1:2,i)=feature_frame{j}(1:2,i)-feature_frame{1}(1:2,i);%Local coordinate of the features
        d_local_feature{j}(1:2,i)=zeros(2,1);%Local deformation of the features
        if i==1
            feature_frame{j}(1:2,i)=feature_frame{j}(1:2,i)+rotation_d*d_local_feature{j}(1:2,i)+noise_record{j};
        else
            feature_frame{j}(1:2,i)=feature_frame{j}(1:2,i)+rotation_d*d_local_feature{j}(1:2,i)+normrnd(0,sigma_cons,2,1);
        end
        plot_feature_gr{j}(1:2,i)=R_ground'*(feature_frame{j}(1:2,i)-point1);
        plot(plot_feature_gr{j}(1,i),plot_feature_gr{j}(2,i),'g*');%Features in different frame
        if i==Num_pose
            plot(plot_feature_gr{j}(1,:),plot_feature_gr{j}(2,:),'-r');%Track feature
        end
    end
    %% KF
    if i==1
        X_update=zeros(1*2,1);
        for j=1:1:Num_feature
            X_update=[X_update;feature_frame{j}(1:2,1)+normrnd(0,sigma_feat,2,1)];
        end
        point1new=X_update(3:4);
        point2new=X_update(5:6);
        theta_e=atan((point2new(2)-point1new(2))/(point2new(1)-point1new(1)));
        R_estimated=[cos(theta_e),-sin(theta_e);sin(theta_e),cos(theta_e)];
        for j=1:1:Num_feature+1
            X_update(2*j-1:2*j)=R_estimated'*(X_update(2*j-1:2*j)-point1new);
        end
        X_update(3:4)=[0;0];
        PX=zeros(2*(Num_feature+1),2*(Num_feature+1));
        PX(1:2,1:2)=sigma_feat^2*eye(2*1);
        PX(5:end,5:end)=2*sigma_feat^2*eye(2*Num_feature-2);
%         J=zeros(Num_feature*2,Num_feature*2);
%         J(1:2,1:2)=-R_estimated';
%         J(3:4,1:2)=-R_estimated';
%         J(3:4,3:4)=R_estimated';
%         J(5:6,1:2)=-R_estimated';
%         J(5:6,5:6)=R_estimated';
%         PX(1:2,:)=[];
%         PX(:,1:2)=[];
%         PX=(J*PX^(-1)*J)^(-1);
%         PXnew=zeros(2*(Num_feature+1),2*(Num_feature+1));
%         PXnew(1:2,1:2)=PX(1:2,1:2);
%         PXnew(5:end,5:end)=PX(3:end,3:end);
%         PX=PXnew;
    else
        %% Smooth measurement
        for j=1:1:Num_feature
            measurement_smooth{j,i}=R_ground'*(rotation_t*translation(1:2,i)+d_local_feature{j}(1:2,i));
        end
        %% Prediction
        Q=blkdiag(sigma_odem^2*eye(2),(sigma_smoo^2+sigma_cons^2)*eye(2),...
          (sigma_smoo^2+sigma_cons^2)*eye(2),(sigma_smoo^2+sigma_cons^2)*eye(2));
        [PX_predict,X_update_predict]=predict(v(i),V_angle(i),Q,PX,sigma_odem,X_update,measurement_smooth,i,R_ground,point1new);
        %% KF Gain
        N=[];
%         plot(X_update_predict(1),X_update_predict(2),'*b');%Track feature
        for j=1:1:Num_feature
            if visble(j,i)==1
                N=blkdiag(N,sigma_feat^2*eye(2));
            end
        end
        for j=1:1:size(constraint_edge,1)
            N=blkdiag(N,sigma_cons^2*eye(2));
        end
        [K,H]=KF_gain(PX_predict,V_angle(i),N,visble(:,i),constraint_edge,Num_feature);
        %% Construction measurement
        for j=1:1:size(constraint_edge,1)
            measurement_construction{i,j}=R_ground'*(local_cordinate_feature{constraint_edge(j,2)}(1:2,i)+...        
            rotation_d*d_local_feature{constraint_edge(j,2)}(1:2,i)-...
            local_cordinate_feature{constraint_edge(j,1)}(1:2,i)-... 
            rotation_d*d_local_feature{constraint_edge(j,1)}(1:2,i));
        end
        %% Feature measurement
        for j=1:1:Num_feature
            if visble(j,i)==1
                measurement_feature{i,j}=R_ground'*(so2_exp(V_angle(i))'*(feature_frame{j}(1:2,i)-Pose(1:2,i)))+normrnd(0,sigma_feat,2,1);
            else
                measurement_feature{i,j}=[];
            end
        end
        %% Update
        [X_update,PX]=KF_update(X_update_predict,K,measurement_construction,measurement_feature,H,PX_predict,i,constraint_edge);
    end
    %% Draw
    plot(X_update(1),X_update(2),'*b');%Track feature
    plot_elipse(X_update(1:2),PX(1:2,1:2)); %Covariance elipse
    for j=1:1:Num_feature
        plot(X_update(2+2*j-1),X_update(2+2*j),'*k');%Track feature
        plot_elipse(X_update(2+2*j-1:2+j*2),PX(2+j*2-1:2+j*2,2+j*2-1:2+j*2)); %Covariance elipse
    end
end
for i=1:1:Num_pose
    Pose_t=R_ground'*(Pose(1:2,i)-point1);
    for j=1:1:Num_feature
        if visble(j,i)==1
            plot([plot_feature_gr{j}(1,i),Pose_t(1)],[plot_feature_gr{j}(2,i),Pose_t(2)],'--b');%Features measurement
        else
            plot([plot_feature_gr{j}(1,i),Pose_t(1)],[plot_feature_gr{j}(2,i),Pose_t(2)],'--y');%Features measurement
        end
    end
end
axis equal
