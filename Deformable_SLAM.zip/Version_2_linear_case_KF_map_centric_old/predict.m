function [PX,X_update_predict]=predict(V,V_angle,Q,PX,sigma_odem,X_update,measurement_smooth,frame_i,R_estimated,point1new)
global dt
R=[cos(V_angle), -sin(V_angle);
    sin(V_angle), cos(V_angle);];
GX=blkdiag(R,eye(2),eye(2),eye(2));
m=R_estimated'*[V;0];
X_update_predict=GX*X_update+...
    [m(1)+normrnd(0,sigma_odem,1,1);m(2)+normrnd(0,sigma_odem,1,1);...
    measurement_smooth{1,frame_i};measurement_smooth{2,frame_i};
    measurement_smooth{3,frame_i}];%
PX=GX*PX*GX'+Q;
