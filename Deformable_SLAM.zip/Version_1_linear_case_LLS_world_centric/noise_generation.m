clc
clear
Num_pose=100;%Total number of the poses
Num_feature=3;%Total number of the features
sigma_smoo=0.03;
sigma_cons=0.02;
sigma_odem=0.002;
sigma_feat=0.005;
for i=1:1:Num_pose-1
        noise_odem1(:,i)=normrnd(0,sigma_odem,2,1);
end
for j=1:1:Num_feature
    for i=1:1:Num_pose
        noise_smoo1{j}(:,i)=normrnd(0,sigma_smoo,2,1);
        noise_feat1{j}(:,i)=normrnd(0,sigma_feat,2,1);
        noise_cons1{j}(:,i)=normrnd(0,sigma_cons,2,1);
    end
end