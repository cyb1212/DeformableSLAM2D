%This code is used to present an linear deformable SLAM framework with
%several poses and 3 deforming features using the traditional measurement,
%struction constaint, and smooth constraint based on the linear least
%squares

% Copyright (C) 2020 by Yongbo Chen, Shoudong Huang, Liang Zhao, and Yanhao
% Zhang

%% Clear environment
clc
clear
close all
warning off
addpath('./Math/');%All mathmatical part espically Lie group

%% Ground truth generation
% pose
Num_pose=100;%Total number of the poses
%v=rand(Num_pose-1,1);%The random translation in every iteration
v=ones(Num_pose-1,1);%The constant translation in every iteration (velocity)
for i=1:1:Num_pose-1%pose generation with zero orientation
    Pose(1,i)=sum(v(1:i));
    Pose(2,i)=0;
    V_angle(i)=0;
end
Pose=[zeros(2,1),Pose];%Add the first pose
V_angle=[0,V_angle];
%% features
% global translation
Num_feature=3;%Total number of the features
% feature=rand(2,Num_feature);%Generate feature in initial frame
feature=[0.5,0.5;0.9,0.8;0.3,0.4]';%Generate fixed feature in initial frame
%translation=rand(2,Num_pose)-repmat([0;0.5],[1,Num_pose]);%random Features global motion
translation=repmat([1;0],[1,Num_pose]);%random Features global motion
rotation_t=eye(2);%No rotation
rotation_d=eye(2);
sigma_smoo=0.3;
sigma_cons=0.2;
% local_cordinate_feature{1}(1:2,i)=[0;0];
% for j=1:1:Num_feature
%     for i=1:1:Num_pose
%         feature_frame{j}(1:2,i)=feature(1:2,j);%Dynamic only features
%         feature(1:2,j)=feature(1:2,j)+rotation_t*translation(1:2,i)+normrnd(0,sigma_smoo,2,1);
% %     end
% % end
% %local deformation
% % for i=1:1:Num_pose
% %     d_local_feature{1}(1:2,i)=0.1*rand(2,1)-0.05;%Local deformation of the first feature
%     d_local_feature{1}(1:2,i)=zeros(2,1);%Local deformation of the first feature
% %     for j=2:1:Num_feature
%         local_cordinate_feature{j}(1:2,i)=feature_frame{j}(1:2,i)-feature_frame{1}(1:2,i);
% %         d_local_feature{j}(1:2,i)=0.1*rand(2,1)-0.05;
%         d_local_feature{j}(1:2,i)=zeros(2,1);%Local deformation of the features
% %     end
% % end
% % 
% % for j=1:1:Num_feature
% %     for i=1:1:Num_pose%Local deformation and generate new deforming features
%         feature_frame{j}(1:2,i)=feature_frame{j}(1:2,i)+rotation_d*d_local_feature{j}(1:2,i)+normrnd(0,sigma_cons,2,1);
%     end
% end

%% Draw ground truth

sigma_odem=0.02;
for i=1:1:Num_feature
    for j=1:1:Num_pose
        if rand(1,1)>0.8
            visble(i,j)=0;
        else
            visble(i,j)=1;
        end
    end
end
visble=ones(Num_feature,Num_pose);
constraint_edge=[];
for i=1:1:Num_feature
    for j=i+1:1:Num_feature
        constraint_edge=[constraint_edge;i,j];%The realtive edge in the construction
    end
end
% axis equal
% value_nees=zeros(1,Num_pose-1);
for num=1:1:50
    feature=[0.5,0.5;0.9,0.8;0.3,0.4]';%Generate fixed feature in initial frame
    local_cordinate_feature{1}(1:2,i)=[0;0];
    for j=1:1:Num_feature
        for i=1:1:Num_pose
            feature_frame{j}(1:2,i)=feature(1:2,j);%Dynamic only features
            feature(1:2,j)=feature(1:2,j)+rotation_t*translation(1:2,i)+normrnd(0,sigma_smoo,2,1);
        end
    end
    %local deformation
    for j=1:1:Num_feature
        for i=1:1:Num_pose
    % for i=1:1:Num_pose
    %     d_local_feature{1}(1:2,i)=0.1*rand(2,1)-0.05;%Local deformation of the first feature
        d_local_feature{1}(1:2,i)=zeros(2,1);%Local deformation of the first feature
    %     for j=2:1:Num_feature
            local_cordinate_feature{j}(1:2,i)=feature_frame{j}(1:2,i)-feature_frame{1}(1:2,i);
    %         d_local_feature{j}(1:2,i)=0.1*rand(2,1)-0.05;
            d_local_feature{j}(1:2,i)=zeros(2,1);%Local deformation of the features
        end
    end
    % 
    for j=1:1:Num_feature
        for i=1:1:Num_pose%Local deformation and generate new deforming features
            feature_frame{j}(1:2,i)=feature_frame{j}(1:2,i)+rotation_d*d_local_feature{j}(1:2,i)+normrnd(0,sigma_cons,2,1);
        end
    end
%     for i=1:1:Num_pose
%         make_plane(Pose(1:2,i), V_angle(i), 0.05, [0,1,1]);%Plot a vehicle to represent a pose
%         for j=1:1:Num_feature
%             plot(feature_frame{j}(1,i),feature_frame{j}(2,i),'g*');%Features in different frame
%     %         plot([feature_frame{j}(1,i),Pose(1,i)],[feature_frame{j}(2,i),Pose(2,i)],'--b');%Features measurement
%         end
%     end
%     for j=1:1:Num_feature%Track feature
%         plot(feature_frame{j}(1,:),feature_frame{j}(2,:),'--r');
%     end
    %% Measurement
    % traditional measurement: odemetry 
    sigma_feat=0.01;
    for i=1:1:Num_pose-1
        measurement_odem{i}=so2_exp(V_angle(i))'*(Pose(1:2,i+1)-Pose(1:2,i))+normrnd(0,sigma_odem,2,1);
    end
    % traditional measurement: feature measurement 
    for i=1:1:Num_pose
        for j=1:1:Num_feature
            if visble(j,i)==1
                measurement_feature{i,j}=so2_exp(V_angle(i))'*(feature_frame{j}(1:2,i)-Pose(1:2,i))+normrnd(0,sigma_feat,2,1);
            else
                measurement_feature{i,j}=[];
            end
        end
    end
    % Construction measurement
    for i=1:1:Num_pose
        for j=1:1:size(constraint_edge,1)
            measurement_construction{i,j}=local_cordinate_feature{constraint_edge(j,2)}(1:2,i)+...        
            rotation_d*d_local_feature{constraint_edge(j,2)}(1:2,i)-...
            local_cordinate_feature{constraint_edge(j,1)}(1:2,i)-... 
            rotation_d*d_local_feature{constraint_edge(j,1)}(1:2,i);
        end
    end
    % Smooth measurement
    for i=1:1:Num_feature
        for j=1:1:Num_pose-1
            measurement_smooth{i,j}=rotation_t*translation(1:2,j)+d_local_feature{i}(1:2,j);
        end
    end
    %% Linear Least square based SLAM
    row=[];
    column=[];
    value=[];
    F=[];
    row_Pw=[];
    column_Pw=[];
    value_Pw=[];
    % traditional Jaccobian: odemetry 
    for i=1:1:Num_pose-1
        row=[row,2*i-1,2*i,2*i-1,2*i];
        column=[column,2*i-1,2*i,2*(i+1)-1,2*(i+1)];
        value=[value,-1,-1,1,1];
        F=[F;measurement_odem{i}];
        row_Pw=[row_Pw,2*i-1,2*i];
        column_Pw=[column_Pw,2*i-1,2*i];
        value_Pw=[value_Pw,sigma_odem^2,sigma_odem^2];
    end
    % traditional Jaccobian: feature measurement 
    for i=1:1:Num_pose
        for j=1:1:Num_feature
            if visble(j,i)==1
                row=[row,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(sum(visble(1:j,i)))-1,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(sum(visble(1:j,i))),...
                    2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(sum(visble(1:j,i)))-1,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(sum(visble(1:j,i)))];
                column=[column,2*i-1,2*i,2*Num_pose+(i-1)*Num_feature*2+2*j-1,2*Num_pose+(i-1)*Num_feature*2+2*j];
                value=[value,-1,-1,1,1];
                F=[F;measurement_feature{i,j}];
                row_Pw=[row_Pw,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(visble(1:j,i))-1,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(visble(1:j,i))];
                column_Pw=[column_Pw,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(visble(1:j,i))-1,2*(Num_pose-1)+sum(sum(visble(1:end,1:i-1)))*2+2*sum(visble(1:j,i))];
                value_Pw=[value_Pw,sigma_feat^2,sigma_feat^2];
            else
            end
        end
    end
    % Constructure Jaccobian
    add_num=2*(Num_pose-1)+sum(sum(visble))*2;
    for i=1:1:Num_pose
        for j=1:1:size(constraint_edge,1)
            row=[row,add_num+(i-1)*size(constraint_edge,1)*2+j*2-1,add_num+(i-1)*size(constraint_edge,1)*2+j*2,...
                add_num+(i-1)*size(constraint_edge,1)*2+j*2-1,add_num+(i-1)*size(constraint_edge,1)*2+j*2];
            column=[column,2*Num_pose+(i-1)*Num_feature*2+constraint_edge(j,1)*2-1,2*Num_pose+(i-1)*Num_feature*2+constraint_edge(j,1)*2,...
                2*Num_pose+(i-1)*Num_feature*2+constraint_edge(j,2)*2-1,2*Num_pose+(i-1)*Num_feature*2+constraint_edge(j,2)*2];
            value=[value,-1,-1,1,1];
            F=[F;measurement_construction{i,j}];
            row_Pw=[row_Pw,add_num+(i-1)*size(constraint_edge,1)*2+j*2-1,add_num+(i-1)*size(constraint_edge,1)*2+j*2];
            column_Pw=[column_Pw,add_num+(i-1)*size(constraint_edge,1)*2+j*2-1,add_num+(i-1)*size(constraint_edge,1)*2+j*2];
            value_Pw=[value_Pw,2*sigma_smoo^2+sigma_cons^2,2*sigma_smoo^2+sigma_cons^2];
        end
    end
    % Smooth measurement
    add_num=2*(Num_pose-1)+sum(sum(visble))*2+2*Num_pose*size(constraint_edge,1);
    for i=1:1:Num_feature
        for j=1:1:Num_pose-1
            row=[row,add_num+(i-1)*(Num_pose-1)*2+j*2-1,add_num+(i-1)*(Num_pose-1)*2+j*2,...
                add_num+(i-1)*(Num_pose-1)*2+j*2-1,add_num+(i-1)*(Num_pose-1)*2+j*2];
            column=[column,2*Num_pose+(j-1)*Num_feature*2+i*2-1,2*Num_pose+(j-1)*Num_feature*2+i*2,...
                2*Num_pose+j*Num_feature*2+i*2-1,2*Num_pose+j*Num_feature*2+i*2];
            value=[value,-1,-1,1,1];
            F=[F;measurement_smooth{i,j}];
            row_Pw=[row_Pw,add_num+(i-1)*(Num_pose-1)*2+j*2-1,add_num+(i-1)*(Num_pose-1)*2+j*2];
            column_Pw=[column_Pw,add_num+(i-1)*(Num_pose-1)*2+j*2-1,add_num+(i-1)*(Num_pose-1)*2+j*2];
            value_Pw=[value_Pw,sigma_smoo^2+sigma_cons^2,sigma_smoo^2+sigma_cons^2];
        end
    end

    Jk=sparse(row,column,value,add_num+Num_feature*(Num_pose-1)*2,Num_feature*Num_pose*2+Num_pose*2);
    Jk(:,1:2)=[];
    % Covariance matrix
    Pw=sparse(row_Pw,column_Pw,value_Pw,size(row_Pw,2),size(row_Pw,2));
    % Linear least square
    X_update_k_1=(Jk'/Pw*Jk)\Jk'/Pw*F;
    % Covariance matrix
    Cov=(Jk'/Pw*Jk)\sparse(eye(Num_feature*Num_pose*2+(Num_pose-1)*2));
    PX=Jk'/Pw*Jk;
    %% NEES
    State_gr=[];
    for i=1:1:Num_pose-1
        e1(:,i)=X_update_k_1(2*i-1:2*i)-Pose(1:2,i+1);
        State_gr=[State_gr;Pose(1:2,i+1)];
        value_nees_p(i,num)=e1(:,i)'*Cov(2*i-1:2*i,2*i-1:2*i)^(-1)*e1(:,i);
    end
    for i=1:1:Num_pose
        for j=1:1:Num_feature%Features in different frames
            e(:,i,j)=X_update_k_1(2*(Num_pose-1)+(i-1)*Num_feature*2+j*2-1:2*(Num_pose-1)+(i-1)*Num_feature*2+j*2)-feature_frame{j}(1:2,i);
            value_nees_f(i,j,num)=e(:,i,j)'*Cov(2*(Num_pose-1)+(i-1)*Num_feature*2+j*2-1:2*(Num_pose-1)+(i-1)*Num_feature*2+j*2,2*(Num_pose-1)+(i-1)*Num_feature*2+j*2-1:2*(Num_pose-1)+(i-1)*Num_feature*2+j*2)^(-1)*e(:,i,j);
            State_gr=[State_gr;feature_frame{j}(1:2,i)];
        end
    end
    value_nees_all(num)=(X_update_k_1-State_gr)'*Cov^(-1)*(X_update_k_1-State_gr);
    %% Plot estimation result
%     for i=1:1:Num_pose-1
%         hold on;
%         plot(X_update_k_1(2*i-1),X_update_k_1(2*i),'g.');% Pose
%         plot_elipse(Pose(1:2,i+1),Cov(2*i-1:2*i,2*i-1:2*i)); %Covariance elipse
%     end
%     for i=1:1:Num_pose
%         hold on;
%         for j=1:1:Num_feature%Features in different frames
%             plot(X_update_k_1(2*(Num_pose-1)+(i-1)*Num_feature*2+j*2-1),X_update_k_1(2*(Num_pose-1)+(i-1)*Num_feature*2+j*2),'g.');
%             if num==1
%                 plot_elipse(feature_frame{j}(1:2,i),Cov(2*(Num_pose-1)+(i-1)*Num_feature*2+j*2-1:2*(Num_pose-1)+(i-1)*Num_feature*2+j*2,2*(Num_pose-1)+(i-1)*Num_feature*2+j*2-1:2*(Num_pose-1)+(i-1)*Num_feature*2+j*2)); %Covariance elipse
%             end
%         end
%     end
end
for i=1:1:Num_pose-1
    NEES_p(i)=sum(value_nees_p(i,:))/num;
end
for i=1:1:Num_pose
    for j=1:1:Num_feature
        NEES_f(i,j)=sum(value_nees_f(i,j,:))/num;
    end
end
upper_bound_pose=chi2inv(0.975,2*num)/num;
lower_bound_pose=chi2inv(0.025,2*num)/num;
NEES_all=sum(value_nees_all)/num
upper_bound_all=chi2inv(0.975,size(Cov,1)*num)/num
lower_bound_all=chi2inv(0.025,size(Cov,1)*num)/num
plot(NEES_p);
for j=1:1:Num_feature
    figure,
    plot(NEES_f(:,j));
end
% for i=1:1:Num_pose
%     for j=1:1:Num_feature
%         if visble(j,i)==1
%             plot([feature_frame{j}(1,i),Pose(1,i)],[feature_frame{j}(2,i),Pose(2,i)],'-k','linewidth',1.5);%Features measurement
%         else
%             plot([feature_frame{j}(1,i),Pose(1,i)],[feature_frame{j}(2,i),Pose(2,i)],'-k','linewidth',1.5);%Features measurement
%         end
%     end
% end
% for i=1:1:Num_pose
%     for j=1:1:Num_feature-1
%             plot([feature_frame{j}(1,i),feature_frame{j+1}(1,i)],[feature_frame{j}(2,i),feature_frame{j+1}(2,i)],'--b');%Features measurement
%     end
%     j=Num_feature;
%     plot([feature_frame{j}(1,i),feature_frame{1}(1,i)],[feature_frame{j}(2,i),feature_frame{1}(2,i)],'--b');%Features measurement
% end
% for i=1:1:Num_pose-1
%     plot([Pose(1,i), Pose(1,i+1)],[Pose(2,i), Pose(2,i+1)], '-y','linewidth',2);%Plot a vehicle to represent a pose
% end
% grid on