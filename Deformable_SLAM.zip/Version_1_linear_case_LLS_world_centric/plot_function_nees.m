subplot(4,1,1);
plot(NEES_p);
hold on;
chi2inv(0.025,50*2)/50*ones(100,1);
plot(ans);
chi2inv(0.975,50*2)/50*ones(100,1);
plot(ans);
subplot(4,1,2);
plot(NEES_f(:,1))
hold on;
chi2inv(0.025,50*2)/50*ones(100,1);
plot(ans);
chi2inv(0.975,50*2)/50*ones(100,1);
plot(ans);
subplot(4,1,1);
plot(NEES_f(:,2))
hold on;
chi2inv(0.025,50*2)/50*ones(100,1);
plot(ans);
chi2inv(0.975,50*2)/50*ones(100,1);
plot(ans);
subplot(4,1,1);
plot(NEES_f(:,3))
hold on;
chi2inv(0.025,50*2)/50*ones(100,1);
plot(ans);
chi2inv(0.975,50*2)/50*ones(100,1);
plot(ans);