function [ A ] = computeA( n )


A = null(n');


end

