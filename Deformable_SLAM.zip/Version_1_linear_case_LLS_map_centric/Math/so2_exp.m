function [ y ] = so2_exp( x )

y= [ cos(x)  -sin(x); sin(x)  cos(x)   ];




end

