function v = so3_hatinv(xi)
v = [xi(3,2); xi(1,3); xi(2,1)];