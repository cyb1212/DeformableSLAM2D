clc
clear
Num_pose=10;%Total number of the poses
Num_feature=3;%Total number of the features
sigma_smoo=0.03;
sigma_cons=0.03;
sigma_feat=0.01;
sigma_odem=0.02;
for i=1:1:Num_pose-1
        noise_odem(:,i)=normrnd(0,sigma_odem,2,1);
end
for j=1:1:Num_feature
    for i=1:1:Num_pose
        noise_smoo{j}(:,i)=normrnd(0,sigma_smoo,2,1);
        noise_feat{j}(:,i)=normrnd(0,sigma_feat,2,1);
        noise_cons{j}(:,i)=normrnd(0,sigma_cons,2,1);
    end
end